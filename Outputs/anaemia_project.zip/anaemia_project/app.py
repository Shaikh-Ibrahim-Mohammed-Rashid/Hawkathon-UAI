from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load model and scaler
model = joblib.load("anaemia_model.joblib")
scaler = joblib.load("scaler.joblib")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        try:
            age = float(request.form['age'])
            gender = 1 if request.form['gender'] == 'Male' else 0
            hemoglobin = float(request.form['hemoglobin'])
            rbc = float(request.form['rbc'])
            mcv = float(request.form['mcv'])
            mch = float(request.form['mch'])
            iron = float(request.form['iron'])

            # Prepare data for prediction
            input_data = np.array([[age, gender, hemoglobin, rbc, mcv, mch, iron]])
            input_scaled = scaler.transform(input_data)
            prediction = model.predict(input_scaled)[0]

            result = "Anaemic" if prediction == 1 else "Normal"
            return render_template('predict.html', prediction=result)

        except Exception as e:
            return render_template('predict.html', prediction=f"Error: {str(e)}")

    return render_template('predict.html', prediction=None)

if __name__ == '__main__':
    app.run(debug=True)
from flask import Flask, request, jsonify, render_template
import random

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')  # your main page

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get("message", "").lower()

    # Basic rule-based chatbot logic
    if "hello" in user_message or "hi" in user_message:
        reply = "Hello! 👋 I'm your AnaemiaCare assistant. How can I help today?"
    elif "anaemia" in user_message:
        reply = "Anaemia occurs when your blood has a lower-than-normal number of red blood cells. Would you like me to tell you common causes or symptoms?"
    elif "symptom" in user_message:
        reply = "Common symptoms include fatigue, pale skin, dizziness, and shortness of breath."
    elif "predict" in user_message or "check" in user_message:
        reply = "You can upload your blood report using the 'Predict Now' feature for an AI-based anaemia analysis."
    else:
        generic_replies = [
            "I'm here to help! Could you tell me more?",
            "Interesting question! Could you clarify what you mean?",
            "Let’s find out together — could you be more specific?",
        ]
        reply = random.choice(generic_replies)

    return jsonify({"reply": reply})

if __name__ == '__main__':
    app.run(debug=True)
 
