import pandas as pd
import numpy as np

# Generate synthetic anaemia dataset
np.random.seed(42)
n = 100  # number of patients

data = {
    "Age": np.random.randint(18, 60, n),
    "Gender": np.random.choice(["Male", "Female"], n),
    "Hemoglobin": np.random.normal(12, 2, n).round(1),
    "RBC": np.random.normal(4.7, 0.5, n).round(1),
    "MCV": np.random.normal(85, 10, n).round(1),
    "MCH": np.random.normal(28, 3, n).round(1),
    "Iron": np.random.normal(70, 15, n).round(1),
}

# Label: Anaemia (1 if Hemoglobin < 12, else 0)
data["Anaemia"] = [1 if hb < 12 else 0 for hb in data["Hemoglobin"]]

df = pd.DataFrame(data)
df.to_csv("anaemia_data.csv", index=False)

print("✅ anaemia_data.csv created successfully!")
print(df.head())
